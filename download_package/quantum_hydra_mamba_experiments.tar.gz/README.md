# Quantum Hydra & Mamba

Quantum State-Space Models for Time-Series and Sequence Classification

## Overview

This repository contains implementations of quantum-enhanced state-space models:

- **QuantumHydra**: Bidirectional quantum processing with three-branch superposition
- **QuantumMamba**: Unidirectional quantum SSM inspired by Mamba architecture
- **QuantumGated**: LSTM-style gating with quantum superposition (best performer)

## Directory Structure

```
quantum_hydra_mamba/
├── models/                     # Model implementations
│   ├── QuantumHydra.py         # Original bidirectional model
│   ├── QuantumHydraHybrid.py   # Hybrid classical-quantum version
│   ├── QuantumMamba.py         # Original unidirectional model
│   ├── QuantumMambaHybrid.py   # Hybrid version
│   ├── QuantumMambaLite.py     # Lightweight variant
│   ├── QuantumMambaHybridLite.py
│   ├── QuantumGatedRecurrence.py  # Gated models (RECOMMENDED)
│   ├── TrueClassicalHydra.py   # Classical baseline
│   ├── TrueClassicalMamba.py   # Classical baseline
│   └── ClassicalHydra.py
│
├── glue/                       # GLUE Benchmark experiments
│   ├── Load_GLUE.py            # Data loader for all 9 GLUE tasks
│   ├── QuantumHydraGLUE.py     # Model wrappers for NLP
│   ├── run_glue.py             # Training script
│   ├── run_glue_*.sh           # SLURM scripts for each task
│   ├── run_all_glue.sh         # Submit all 9 tasks
│   └── GLUE_README.md          # GLUE documentation
│
├── data_loaders/               # Data loading utilities
│   ├── Load_PhysioNet_EEG.py
│   ├── Load_PhysioNet_EEG_NoPrompt.py
│   ├── Load_DNA_Sequences.py
│   ├── Load_Genomic_Benchmarks.py
│   ├── forrelation_dataloader.py
│   └── generate_forrelation_dataset.py
│
├── scripts/                    # Training and analysis scripts
│   ├── run_gated_models.py     # Train gated models
│   ├── run_gated_genomic.py    # Genomic experiments
│   ├── run_single_model_*.py   # Single model training
│   ├── aggregate_*_results.py  # Result aggregation
│   └── generate_*_job_scripts.py
│
├── job_scripts/                # SLURM batch scripts
│   ├── eeg/                    # EEG experiment jobs
│   ├── dna/                    # DNA experiment jobs
│   ├── gated/                  # Gated model jobs
│   └── *.sh                    # Various submission scripts
│
├── results/                    # Experiment results
│   ├── eeg_results/            # EEG classification results
│   ├── eeg_8q_160hz/           # 8-qubit EEG experiments
│   ├── dna_results/            # DNA classification results
│   ├── dna_stratified/         # Stratified DNA results
│   ├── mnist_results/          # MNIST classification results
│   ├── genomic/                # Genomic benchmark results
│   ├── gated/                  # Gated model results
│   ├── glue/                   # GLUE benchmark results
│   ├── forrelation_results/    # Forrelation (quantum advantage) results
│   └── multigpu/               # Multi-GPU experiment results
│
├── circuits/                   # Quantum circuit diagrams (PDF)
│   ├── 01_qshift_circuit.pdf
│   ├── 02_qflip_circuit.pdf
│   ├── 03_qlcu_circuit.pdf
│   └── ...
│
├── docs/                       # Documentation
│   ├── QUANTUM_GATED_RECURRENCE_GUIDE.md
│   ├── QUANTUM_GATED_RESULTS_SUMMARY.md
│   ├── TIER1_EXPERIMENTS_SUMMARY.md
│   ├── WORK_COMPLETED_SUMMARY.md
│   └── ...
│
└── README.md                   # This file
```

## Model Comparison

| Model | Architecture | Best Use Case | Sequence Limit |
|-------|--------------|---------------|----------------|
| **QuantumHydraGated** | Bidirectional + 3-gate | All tasks | None |
| QuantumMambaGated | Unidirectional + 3-gate | Short sequences | ~1000 steps |
| QuantumHydra | Bidirectional | Medium sequences | ~500 steps |
| QuantumMamba | Unidirectional | Short sequences | ~200 steps |
| QuantumHydraHybrid | Hybrid | Large datasets | ~500 steps |

**Recommendation**: Use `QuantumHydraGated` for best results on any sequence length.

## Quick Start

### 1. EEG Classification

```bash
cd /pscratch/sd/j/junghoon/quantum_hydra_mamba
python scripts/run_gated_models.py \
    --model-name=quantum_hydra_gated \
    --dataset=eeg \
    --n-qubits=6 \
    --n-epochs=50
```

### 2. Genomic Classification

```bash
python scripts/run_gated_genomic.py \
    --model-name=quantum_hydra_gated \
    --dataset=human_enhancers_cohn \
    --n-qubits=6
```

### 3. GLUE Benchmark

```bash
cd glue

# Quick test
python run_glue.py --task=sst2 --model=quantum_hydra --mini --n-epochs=5

# Full experiment (all 9 tasks)
bash run_all_glue.sh
```

### 4. Submit SLURM Jobs

```bash
# Single job
sbatch job_scripts/eeg/eeg_quantum_hydra_seed2024.sh

# All EEG jobs
bash job_scripts/eeg/submit_all_eeg_jobs.sh
```

## Key Results

### EEG Motor Imagery (PhysioNet)

| Model | Accuracy | AUC |
|-------|----------|-----|
| QuantumHydraGated | 70.32% ± 1.56% | 0.76 |
| QuantumMambaGated | 69.38% ± 3.64% | 0.74 |
| Classical Mamba | 68.5% | 0.73 |
| Random | 50% | 0.50 |

### Genomic Benchmarks

| Dataset | HydraGated | MambaGated | Seq Length |
|---------|------------|------------|------------|
| Human Enhancers (500bp) | 72% | 72% | 500 |
| Mouse Enhancers (4776bp) | 76.5% | 50% (FAILS) | 4776 |

## Architecture Details

### Quantum Superposition

All models use three-branch quantum superposition:

```
|ψ⟩ = α|ψ₁⟩ + β|ψ₂⟩ + γ|ψ₃⟩
```

where α, β, γ are learnable complex coefficients.

### Gated Recurrence

The Gated models add LSTM-style gating:

- **Forget gate**: Controls what to forget from previous state
- **Input gate**: Controls what new information to add
- **Output gate**: Controls what to output (critical for long sequences)

### Chunked Processing

Long sequences are processed in chunks for efficiency:

```
O(T/chunk_size) quantum circuit calls instead of O(T)
```

## Requirements

```
torch>=2.0
pennylane>=0.35
numpy
scikit-learn
tqdm

# For GLUE experiments
datasets>=2.14
transformers>=4.30
```

## Environment Setup

```bash
conda activate /pscratch/sd/j/junghoon/conda-envs/qml_eeg
```
